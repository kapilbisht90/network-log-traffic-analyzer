from collections import Counter
from dataclasses import dataclass
from typing import Iterable

from .parser import LogEntry


@dataclass
class AnalysisResult:
    total_entries: int
    top_src_ips: list
    top_dst_ips: list
    top_dst_ports: list
    action_counts: dict
    protocol_counts: dict
    blocked_connections: list


def analyze_logs(entries: Iterable[LogEntry], top_n: int = 10) -> AnalysisResult:
    logs = list(entries)
    blocked = [entry for entry in logs if entry.action in {"DENY", "DROP", "BLOCK"}]
    return AnalysisResult(
        total_entries=len(logs),
        top_src_ips=Counter(entry.src_ip for entry in logs).most_common(top_n),
        top_dst_ips=Counter(entry.dst_ip for entry in logs).most_common(top_n),
        top_dst_ports=Counter(entry.dst_port for entry in logs if entry.dst_port is not None).most_common(top_n),
        action_counts=dict(Counter(entry.action for entry in logs)),
        protocol_counts=dict(Counter(entry.protocol for entry in logs)),
        blocked_connections=blocked,
    )
