import csv
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional


@dataclass
class LogEntry:
    timestamp: Optional[datetime]
    src_ip: str
    dst_ip: str
    src_port: Optional[int]
    dst_port: Optional[int]
    protocol: str
    action: str
    bytes_sent: Optional[int] = None
    bytes_recv: Optional[int] = None


def parse_csv_logs(path: Path) -> Iterable[LogEntry]:
    with path.open(newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):
            yield _to_entry(row)


def parse_jsonl_logs(path: Path) -> Iterable[LogEntry]:
    with path.open(encoding="utf-8") as file:
        for line in file:
            if line.strip():
                yield _to_entry(json.loads(line))


TEXT_PATTERN = re.compile(
    r"(?P<timestamp>\S+)\s+(?P<action>ALLOW|DENY|DROP)\s+"
    r"(?P<protocol>\w+)\s+(?P<src_ip>[\d.]+):(?P<src_port>\d+)\s*->\s*"
    r"(?P<dst_ip>[\d.]+):(?P<dst_port>\d+)(?:\s+bytes=(?P<bytes_sent>\d+))?",
    re.IGNORECASE,
)


def parse_text_logs(path: Path) -> Iterable[LogEntry]:
    with path.open(encoding="utf-8") as file:
        for line in file:
            match = TEXT_PATTERN.match(line.strip())
            if match:
                yield _to_entry(match.groupdict())


def _to_entry(row: dict) -> LogEntry:
    timestamp = _timestamp(row.get("timestamp") or row.get("ts") or row.get("time"))
    return LogEntry(
        timestamp=timestamp,
        src_ip=row.get("src_ip") or row.get("source_ip") or "",
        dst_ip=row.get("dst_ip") or row.get("dest_ip") or "",
        src_port=_number(row.get("src_port") or row.get("source_port")),
        dst_port=_number(row.get("dst_port") or row.get("dest_port") or row.get("port")),
        protocol=(row.get("protocol") or row.get("proto") or "UNKNOWN").upper(),
        action=(row.get("action") or row.get("verdict") or "UNKNOWN").upper(),
        bytes_sent=_number(row.get("bytes_sent") or row.get("bytes")),
        bytes_recv=_number(row.get("bytes_recv")),
    )


def _number(value):
    try:
        return int(value) if value not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _timestamp(value):
    if not value:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            pass
    return None
