import argparse
from pathlib import Path

from .analyzer import analyze_logs
from .parser import parse_csv_logs, parse_jsonl_logs, parse_text_logs
from .report import write_reports


def main():
    parser = argparse.ArgumentParser(description="Network Log Traffic Analyzer")
    parser.add_argument("log_file", type=Path, help="Path to log file (CSV, JSONL, or TXT)")
    parser.add_argument("--format", choices=["auto", "csv", "jsonl", "text"], default="auto",
                        help="Log format (default: auto-detect)")
    parser.add_argument("--output-dir", type=Path, default=Path("output"), help="Output directory")
    parser.add_argument("--top", type=int, default=10, help="Number of top items to show")
    args = parser.parse_args()

    fmt = args.format
    if fmt == "auto":
        fmt = "csv" if args.log_file.suffix.lower() == ".csv" else "jsonl" if args.log_file.suffix.lower() == ".jsonl" else "text"

    loaders = {"csv": parse_csv_logs, "jsonl": parse_jsonl_logs, "text": parse_text_logs}
    result = analyze_logs(loaders[fmt](args.log_file), args.top)
    report, blocked = write_reports(result, args.output_dir)

    print(f"Analyzed {result.total_entries} log entries")
    print(f"Actions: {result.action_counts}")
    print(f"Blocked connections: {len(result.blocked_connections)}")
    print(f"Reports: {report} and {blocked}")


if __name__ == "__main__":
    main()
