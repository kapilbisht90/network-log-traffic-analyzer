# Network Log Traffic Analyzer

A professional Python CLI tool for analyzing network and firewall traffic logs to identify security threats and traffic patterns.

## Features
- Multi-format log parsing (CSV, JSONL, plain text)
- Traffic analytics: top source/destination IPs, port usage, protocol distribution
- Security insights: blocked connections, denied traffic analysis
- Export reports in JSON and CSV formats for SIEM integration

## Quick Start
```bash
python -m network_log_traffic_analyzer.cli data/sample_logs.csv --output-dir output
```

## Installation
```bash
pip install -e .
```

## Usage Examples
```bash
# Analyze CSV logs
netlog-traffic data/sample_logs.csv --output-dir reports

# Analyze JSONL logs
netlog-traffic firewall.jsonl --format jsonl --output-dir reports

# Custom top-N results
netlog-traffic logs.csv --top 20 --output-dir reports
```

## Output
- `analysis_report.json` — Summary metrics and top talkers
- `blocked_connections.csv` — All DENY/DROP entries for incident response

## License
MIT
