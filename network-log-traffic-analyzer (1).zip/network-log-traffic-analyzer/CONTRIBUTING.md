# Contributing

1. Fork and clone
2. Create branch
3. Make changes
4. Run tests: `pytest tests/`
5. Submit PR

Thanks!
