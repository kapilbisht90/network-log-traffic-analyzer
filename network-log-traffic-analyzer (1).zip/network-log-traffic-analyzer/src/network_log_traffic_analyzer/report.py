"""Report generation module."""

import csv
import json
from pathlib import Path

from .analyzer import AnalysisResult


def write_reports(result: AnalysisResult, output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "analysis_report.json"
    blocked_path = output_dir / "blocked_connections.csv"

    payload = {
        "total_entries": result.total_entries,
        "top_src_ips": [{"ip": ip, "count": count} for ip, count in result.top_src_ips],
        "top_dst_ips": [{"ip": ip, "count": count} for ip, count in result.top_dst_ips],
        "top_dst_ports": [{"port": p, "count": c} for p, c in result.top_dst_ports],
        "action_counts": result.action_counts,
        "protocol_counts": result.protocol_counts,
        "blocked_count": len(result.blocked_connections),
    }

    report_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    fields = ["timestamp", "src_ip", "src_port", "dst_ip", "dst_port", "protocol", "action", "bytes_sent", "bytes_recv"]
    with blocked_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for item in result.blocked_connections:
            writer.writerow({
                "timestamp": item.timestamp.isoformat() if item.timestamp else "",
                "src_ip": item.src_ip,
                "src_port": item.src_port or "",
                "dst_ip": item.dst_ip,
                "dst_port": item.dst_port or "",
                "protocol": item.protocol,
                "action": item.action,
                "bytes_sent": item.bytes_sent or "",
                "bytes_recv": item.bytes_recv or "",
            })

    return report_path, blocked_path
