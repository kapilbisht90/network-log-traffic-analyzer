"""Analytics module."""

from collections import Counter
from dataclasses import dataclass
from typing import Iterable

from .parser import LogEntry


@dataclass
class AnalysisResult:
    total_entries: int
    top_src_ips: list[tuple[str, int]]
    top_dst_ips: list[tuple[str, int]]
    top_dst_ports: list[tuple[int, int]]
    action_counts: dict[str, int]
    protocol_counts: dict[str, int]
    blocked_connections: list[LogEntry]


def analyze_logs(entries: Iterable[LogEntry], top_n: int = 10) -> AnalysisResult:
    logs = list(entries)
    blocked = [e for e in logs if e.action in {"DENY", "DROP", "BLOCK"}]
    return AnalysisResult(
        total_entries=len(logs),
        top_src_ips=Counter(e.src_ip for e in logs).most_common(top_n),
        top_dst_ips=Counter(e.dst_ip for e in logs).most_common(top_n),
        top_dst_ports=Counter(e.dst_port for e in logs if e.dst_port is not None).most_common(top_n),
        action_counts=dict(Counter(e.action for e in logs)),
        protocol_counts=dict(Counter(e.protocol for e in logs)),
        blocked_connections=blocked,
    )
